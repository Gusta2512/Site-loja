import json
from flask import Flask, render_template, request, session, redirect, url_for, jsonify
from geopy.geocoders import Nominatim
from geopy.distance import geodesic

app = Flask(__name__)
app.secret_key = 'chave_secreta'

# Especifique a codificação utf-8 ao abrir o arquivo
with open('produtos.json', 'r', encoding='utf-8') as f:
    produtos = json.load(f)

# Tentar geocodificar o endereço da confeitaria
confeitaria_endereco = "Av. Coronel Manuel Py, 345 - Lauzane Paulista, São Paulo - SP, 02442-090"  # Endereço mais específico
geolocator = Nominatim(user_agent="confeitaria_app")

try:
    confeitaria_localizacao = geolocator.geocode(confeitaria_endereco)
    if confeitaria_localizacao is None:
        raise ValueError("Endereço da confeitaria não encontrado.")
    confeitaria_coordenadas = (confeitaria_localizacao.latitude, confeitaria_localizacao.longitude)
except (ValueError, Exception) as e:
    print(f"Erro ao geocodificar o endereço da confeitaria: {e}")
    print("Usando coordenadas alternativas (MASP - São Paulo).")
    confeitaria_coordenadas = (-23.561414, -46.655881)  # Coordenadas do MASP como fallback

# Função para calcular a taxa de entrega com base na distância
def calcular_taxa_entrega(endereco_cliente):
    try:
        cliente_localizacao = geolocator.geocode(endereco_cliente)
        cliente_coordenadas = (cliente_localizacao.latitude, cliente_localizacao.longitude)
        distancia = geodesic(confeitaria_coordenadas, cliente_coordenadas).km

        # Definir uma taxa de entrega com base na distância
        if distancia <= 5:
            taxa_entrega = 5.0
        elif distancia <= 10:
            taxa_entrega = 10.0
        else:
            taxa_entrega = 15.0  # Taxa para distâncias maiores

        return taxa_entrega
    except Exception as e:
        print(f"Erro ao calcular a taxa de entrega: {e}")
        return None

@app.route('/')
def index():
    return render_template('index.html', produtos=produtos)

@app.route('/adicionar_ao_carrinho', methods=['POST'])
def adicionar_ao_carrinho():
    produto_id = request.form['produto_id']
    quantidade = int(request.form['quantidade'])

    if 'carrinho' not in session:
        session['carrinho'] = []

    carrinho = session['carrinho']
    produto = next((p for p in produtos if p['id'] == int(produto_id)), None)

    if produto:
        item_existente = next((item for item in carrinho if item['id'] == produto['id']), None)
        if item_existente:
            item_existente['quantidade'] += quantidade
        else:
            carrinho.append({'id': produto['id'], 'nome': produto['nome'], 'preco': produto['preco'], 'quantidade': quantidade, 'imagem': produto['imagem']})

    session['carrinho'] = carrinho
    return jsonify({'mensagem': 'Produto adicionado ao carrinho!', 'carrinho': session['carrinho']})

@app.route('/remover_do_carrinho', methods=['POST'])
def remover_do_carrinho():
    produto_id = int(request.form['produto_id'])
    carrinho = session.get('carrinho', [])

    item_removido = False
    for item in carrinho:
        if item['id'] == produto_id:
            carrinho.remove(item)
            item_removido = True
            break

    if item_removido:
        session['carrinho'] = carrinho
        total = sum(item['preco'] * item['quantidade'] for item in carrinho)
        return jsonify({'mensagem': 'Item removido do carrinho!', 'carrinho': carrinho, 'total': total}) # Retorna o carrinho e o total
    else:
        return jsonify({'mensagem': 'Item não encontrado no carrinho!'}), 404

@app.route('/carrinho')
def ver_carrinho():
    return render_template('carrinho.html')

@app.route('/checkout', methods=['GET', 'POST'])
def checkout():
    if request.method == 'POST':
        endereco = request.form['endereco']
        taxa_entrega = calcular_taxa_entrega(endereco)

        if taxa_entrega is not None:
            carrinho = session.get('carrinho', [])
            total_pedido = sum(item['preco'] * item['quantidade'] for item in carrinho)
            total_pedido += taxa_entrega

            session['carrinho'] = []
            return render_template('confirmacao_pedido.html', total_pedido=total_pedido, taxa_entrega=taxa_entrega)
        else:
            return "Erro ao calcular a taxa de entrega. Verifique o endereço e tente novamente."

    return render_template('checkout.html')

if __name__ == '__main__':
    app.run(debug=True, port=5010)
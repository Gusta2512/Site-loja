document.addEventListener("DOMContentLoaded", function () {
    console.log("Script carregado!");

    document.querySelectorAll(".add-to-cart").forEach(button => {
        button.addEventListener("click", function () {
            const name = this.getAttribute("data-name");
            const price = parseFloat(this.getAttribute("data-price"));

            addToCart(name, price);
        });
    });

    // Adiciona o evento ao botão de finalizar compra quando o DOM estiver carregado
    const checkoutButton = document.getElementById("checkout-button");
    if (checkoutButton) {
        checkoutButton.addEventListener("click", checkout);
    }
});

// Array para armazenar os itens do carrinho
let cart = [];

// Função para adicionar itens ao carrinho e atualizar a interface
function addToCart(name, price) {
    console.log(`Produto adicionado: ${name} - R$ ${price.toFixed(2)}`);

    // Verifica se o item já está no carrinho
    let itemExistente = cart.find(item => item.name === name);
    if (itemExistente) {
        itemExistente.quantidade += 1; // Incrementa a quantidade se o item já existir
    } else {
        cart.push({ name, price, quantidade: 1 }); // Adiciona o item com quantidade 1
    }

    // Atualiza a exibição do carrinho no site
    updateCart();
}

// Função para remover item do carrinho
function removeFromCart(index) {
    console.log(`Removendo item: ${cart[index].name}`);

    // Remove o item do array do carrinho
    cart.splice(index, 1);

    // Atualiza a exibição do carrinho
    updateCart();
}

// Função para atualizar o HTML do carrinho
function updateCart() {
    const cartList = document.getElementById("cart-items");
    const totalElement = document.getElementById("total");

    // Limpa a lista antes de recriar os itens
    cartList.innerHTML = "";

    let total = 0;

    cart.forEach((item, index) => {
        const li = document.createElement("li");
        li.innerHTML = `${item.name} - R$ ${item.price.toFixed(2)} (Quantidade: ${item.quantidade})  
            <button class="remove-btn" data-index="${index}">Remover Item</button>`;
        
        cartList.appendChild(li);
        total += item.price * item.quantidade;
    });

    // Atualiza o total
    totalElement.textContent = total.toFixed(2);

    // Re-adiciona o evento de clique nos botões de remover
    document.querySelectorAll(".remove-btn").forEach(button => {
        button.addEventListener("click", function () {
            const index = this.getAttribute("data-index");
            removeFromCart(index);
        });
    });
}

// Função de checkout (limpa o carrinho e envia para o WhatsApp)
function checkout() {
    console.log("Finalizando compra...");
    
    // Obtemos os dados do usuário
    const userName = document.getElementById("user-name").value;
    const userAddress = document.getElementById("user-address").value;
    const userCpf = document.getElementById("user-cpf").value;

    // Verifica se todos os dados estão preenchidos
    if (!userName || !userAddress || !userCpf) {
        alert("Por favor, preencha todos os campos antes de finalizar a compra.");
        return;
    }

    // Criar a mensagem que será enviada via WhatsApp
    const cartItems = cart.map(item => `${item.name} - R$ ${item.price.toFixed(2)} (Quantidade: ${item.quantidade})`).join("\n");
    const total = cart.reduce((sum, item) => sum + item.price * item.quantidade, 0).toFixed(2);
    
    const message = `🛒 Pedido de ${userName}\n\nItens:\n${cartItems}\n\nTotal: R$ ${total}\n\nEndereço: ${userAddress}\nCPF: ${userCpf}\n\nPor favor, envie para confirmar o pedido!`;

    // Substituir os espaços por "%20" para formatar a URL corretamente
    const whatsappNumber = "5511987890047"; // Substitua pelo número de WhatsApp que receberá o pedido
    const whatsappURL = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`;

    // Abrir o WhatsApp em uma nova aba
    window.open(whatsappURL, "_blank");

    // Limpar o carrinho após o envio
    cart = [];
    updateCart();
    alert("Pedido enviado para o WhatsApp!");
}

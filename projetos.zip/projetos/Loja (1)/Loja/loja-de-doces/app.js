const express = require("express");
const helmet = require("helmet");
const path = require("path");
const mysql = require("mysql2");

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Configurar Helmet
app.use(
    helmet({
        contentSecurityPolicy: {
            directives: {
                defaultSrc: ["'self'"],
                scriptSrc: ["'self'", "'unsafe-inline'"],
                styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
                imgSrc: ["'self'", "data:", "https://via.placeholder.com", "http://localhost:3000"],
            },
        },
    })
);

// Configuração do MySQL
const connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "Bleach223@",
    database: "loja_sql",
});

connection.connect((err) => {
    if (err) {
        console.error("Erro ao conectar ao MySQL:", err);
        return;
    }
    console.log("Conectado ao MySQL!");
});

// Definir EJS como motor de template
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// Servir arquivos estáticos
app.use(express.static(path.join(__dirname, "public")));

// Rota inicial
app.get("/", (req, res) => {
    res.render("index");
});

// 📌 Rota para cadastrar um cliente
app.post("/clientes", (req, res) => {
    const { cpf, nome, endereco } = req.body;

    console.log("Recebendo dados:", req.body); // Log dos dados recebidos

    if (!cpf || !nome || !endereco) {
        console.log("Erro: Campos obrigatórios ausentes");
        return res.status(400).json({ error: "Todos os campos são obrigatórios" });
    }

    // Inserir cliente no banco com pedidos = 0 e desconto = 0
    const sql = "INSERT INTO clientes (cpf, nome, endereco, pedidos, desconto) VALUES (?, ?, ?, 0, 0)";
    connection.query(sql, [cpf, nome, endereco], (err, result) => {
        if (err) {
            console.error("Erro ao inserir cliente:", err);
            return res.status(500).json({ error: "Erro no servidor" });
        }

        console.log("Cliente cadastrado com sucesso!", result);
        res.status(201).json({ message: "Cliente cadastrado com sucesso!", id: result.insertId });
    });
});

// 📌 Rota para registrar um pedido e gerar link do WhatsApp
app.post("/pedidos", (req, res) => {
    const { cpf } = req.body;

    if (!cpf) {
        return res.status(400).json({ error: "CPF é obrigatório" });
    }

    connection.query("SELECT * FROM clientes WHERE cpf = ?", [cpf], (err, results) => {
        if (err) {
            console.error("Erro ao verificar cliente:", err);
            return res.status(500).json({ error: "Erro no servidor" });
        }

        if (results.length === 0) {
            return res.status(404).json({ error: "Cliente não encontrado" });
        }

        const cliente = results[0];
        const novosPedidos = cliente.pedidos + 1;
        let novoDesconto = cliente.desconto;

        if (novosPedidos >= 5) {
            novoDesconto = 10; // Aplicar 10% de desconto após 5 pedidos
        }

        connection.query(
            "UPDATE clientes SET pedidos = ?, desconto = ? WHERE cpf = ?",
            [novosPedidos, novoDesconto, cpf],
            (err, result) => {
                if (err) {
                    console.error("Erro ao atualizar cliente:", err);
                    return res.status(500).json({ error: "Erro ao atualizar o cliente" });
                }

                const mensagem = `Novo pedido!\nNome: ${cliente.nome}\nCPF: ${cliente.cpf}\nEndereço: ${cliente.endereco}\nPedidos anteriores: ${novosPedidos - 1}\nDesconto atual: ${novoDesconto}%`;
                const numeroWhatsApp = "55SEUNUMERO"; // Substitua pelo seu número com DDD
                const linkWhatsApp = `https://api.whatsapp.com/send?phone=${numeroWhatsApp}&text=${encodeURIComponent(mensagem)}`;

                console.log("Pedido registrado! Link do WhatsApp:", linkWhatsApp);
                res.status(200).json({
                    message: "Pedido registrado com sucesso!",
                    desconto: novoDesconto,
                    linkWhatsApp,
                });
            }
        );
    });
});

// Iniciar servidor
const PORT = 30099;
app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
});

// Testar conexão com MySQL
connection.query("SELECT 1", (err, result) => {
    if (err) {
        console.error("Erro na conexão com MySQL:", err);
    } else {
        console.log("Conexão com MySQL está funcionando!");
    }

    const express = require("express");
const app = express();
const path = require("path");

app.set("view engine", "ejs"); 
app.set("views", path.join(__dirname, "views/templates")); 
app.use(express.static("public")); 

app.get("/", (req, res) => {
    res.render("index");
});

app.get("/fotos", (req, res) => {
    res.render("fotos");
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
});
});

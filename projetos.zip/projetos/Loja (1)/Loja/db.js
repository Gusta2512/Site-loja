const mysql = require('mysql2');

// Configurar a conexão com o MySQL
const connection = mysql.createConnection({
    host: 'localhost',  // ou IP do seu servidor MySQL
    user: 'root',       // seu usuário do MySQL
    password: '',       // sua senha do MySQL
    database: 'meu_site' // nome do banco de dados
});

// Conectar ao banco de dados
connection.connect((err) => {
    if (err) {
        console.error('Erro ao conectar ao MySQL:', err);
        return;
    }
    console.log('Conectado ao MySQL!');
});

module.exports = connection;
